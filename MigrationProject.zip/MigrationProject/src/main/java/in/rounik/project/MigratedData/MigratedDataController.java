package in.rounik.project.MigratedData;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import in.rounik.project.Filter.Filter;
import in.rounik.project.KBObjects.KBArticle;
import in.rounik.project.KBObjects.KBFolder;

@RestController
public class MigratedDataController {

    @Autowired
    private MigratedDataService migratedDataService;

    @GetMapping("/migratedFolders/count")
    public ResponseEntity<?> getFoldersCount() {
        long count = migratedDataService.getFoldersCount();
        return ResponseEntity.ok().body(count);
    }

    @GetMapping("/migratedFolders/{id}")
    public ResponseEntity<?> getFolderById(@PathVariable String id) {
        KBFolder folder = migratedDataService.getFolderById(id);
        if (folder != null) {
            return ResponseEntity.ok().body(folder);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/migratedFolders/{id}")
    public ResponseEntity<?> deleteFolder(@PathVariable String id) {
        boolean isDeleted = migratedDataService.deleteFolder(id);
        if (isDeleted) {
            return ResponseEntity.ok().body("Folder deleted successfully");
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/migratedFolders")
    public ResponseEntity<?> deleteAllFolders() {
        migratedDataService.deleteAllFolders();
        return ResponseEntity.ok().body("All folders deleted successfully");
    }

    @PostMapping("/migratedFolders")
    public ResponseEntity<?> saveFolder(@RequestBody KBFolder migratedFolder) {
        migratedDataService.saveFolder(migratedFolder);
        return ResponseEntity.ok().body("Folder saved successfully");
    }

    @GetMapping("/migratedArticles/count")
    public ResponseEntity<?> getArticlesCount() {
        long count = migratedDataService.getArticlesCount();
        return ResponseEntity.ok().body(count);
    }

    @GetMapping("/migratedArticles/{id}")
    public ResponseEntity<?> getArticleById(@PathVariable String id) {
        KBArticle article = migratedDataService.getArticleById(id);
        if (article != null) {
            return ResponseEntity.ok().body(article);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/migratedArticles/{id}")
    public ResponseEntity<?> deleteArticle(@PathVariable String id) {
        boolean isDeleted = migratedDataService.deleteArticle(id);
        if (isDeleted) {
            return ResponseEntity.ok().body("Article deleted successfully");
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/migratedArticles")
    public ResponseEntity<?> deleteAllArticles() {
        migratedDataService.deleteAllArticles();
        return ResponseEntity.ok().body("All articles deleted successfully");
    }

    @PostMapping("/migratedArticles")
    public ResponseEntity<?> saveArticle(@RequestBody KBArticle migratedArticle) {
        migratedDataService.saveArticle(migratedArticle);
        return ResponseEntity.ok().body("Article saved successfully");
    }

    @GetMapping("/migratedFolders")
    public ResponseEntity<?> getFilteredFolders(@RequestBody(required = false) List<Filter> filters,
                                                @RequestParam(value = "page", defaultValue = "0") int page,
                                                @RequestParam(value = "size", defaultValue = "10") int size) {
        if (filters == null) {
            filters = List.of();
        }
        Pageable pageable = PageRequest.of(page, size);
        Page<KBFolder> folders = migratedDataService.getFilteredPagedFolders(filters, pageable);
        return ResponseEntity.ok().body(folders);
    }

    @GetMapping("/migratedArticles")
    public ResponseEntity<?> getFilteredArticles(@RequestBody(required = false) List<Filter> filters,
                                                 @RequestParam(value = "page", defaultValue = "0") int page,
                                                 @RequestParam(value = "size", defaultValue = "10") int size) {
        if (filters == null) {
            filters = List.of();
        }
        Pageable pageable = PageRequest.of(page, size);
        Page<KBArticle> articles = migratedDataService.getFilteredPagedArticles(filters, pageable);
        return ResponseEntity.ok().body(articles);
    }
}

