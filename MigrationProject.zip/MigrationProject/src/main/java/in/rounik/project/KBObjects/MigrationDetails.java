package in.rounik.project.KBObjects;

public class MigrationDetails {
    private String migratedId;
    private String migratedFrom;

    public MigrationDetails() {
    }

    public MigrationDetails(String migratedId, String migratedFrom) {
        this.migratedId = migratedId;
        this.migratedFrom = migratedFrom;
    }

    public String getMigratedId() {
        return migratedId;
    }

    public void setMigratedId(String migratedId) {
        this.migratedId = migratedId;
    }

    public String getMigratedFrom() {
        return migratedFrom;
    }

    public void setMigratedFrom(String migratedFrom) {
        this.migratedFrom = migratedFrom;
    }

}
