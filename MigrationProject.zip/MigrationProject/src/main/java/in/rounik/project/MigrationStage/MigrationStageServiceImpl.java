package in.rounik.project.MigrationStage;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import in.rounik.project.DumpData.DumpedArticle;
import in.rounik.project.DumpData.DumpedFolder;
import in.rounik.project.Filter.Filter;
import in.rounik.project.Filter.FilterType;
import in.rounik.project.MigratedData.MigratedDataService;

@Service
public class MigrationStageServiceImpl implements MigrationStageService {

    @Autowired
    private MongoTemplate mongoTemplate;

    @Autowired
    private MigratedDataService migratedDataService;

    private final Map<FilterType, BiFunction<String, List<Object>, Criteria>> criteriaMap = new HashMap<>();

    public MigrationStageServiceImpl() {
        criteriaMap.put(FilterType.EQUAL, (field, values) -> Criteria.where(field).is(values.get(0)));
        criteriaMap.put(FilterType.NOT_EQUAL, (field, values) -> Criteria.where(field).ne(values.get(0)));
        criteriaMap.put(FilterType.GT, (field, values) -> Criteria.where(field).gt(values.get(0)));
        criteriaMap.put(FilterType.GTE, (field, values) -> Criteria.where(field).gte(values.get(0)));
        criteriaMap.put(FilterType.LT, (field, values) -> Criteria.where(field).lt(values.get(0)));
        criteriaMap.put(FilterType.LTE, (field, values) -> Criteria.where(field).lte(values.get(0)));
        criteriaMap.put(FilterType.CONTAINING, (field, values) -> Criteria.where(field).regex((String) values.get(0)));
        criteriaMap.put(FilterType.NOT_CONTAINING, (field, values) -> Criteria.where(field).not().regex((String) values.get(0)));
        criteriaMap.put(FilterType.BETWEEN, (field, values) -> Criteria.where(field).gte(values.get(0)).lte(values.get(1)));
        criteriaMap.put(FilterType.IN, (field, values) -> Criteria.where(field).in(values));
        criteriaMap.put(FilterType.NOT_IN, (field, values) -> Criteria.where(field).nin(values));
    }

    @Override
    public ResponseEntity<?> MigrateFoldersWithFilters(List<Filter> filters) {
        Query query = new Query();
        for (Filter filter : filters) {
            BiFunction<String, List<Object>, Criteria> criteriaFunction = criteriaMap.get(filter.getFilterType());
            if (criteriaFunction != null) {
                query.addCriteria(criteriaFunction.apply(filter.getField(), filter.getValues()));
            }
        }
        List<DumpedFolder> folders = mongoTemplate.find(query, DumpedFolder.class);
        for (DumpedFolder folder : folders) {
            migratedDataService.migrateFolder(folder);
        }
        return ResponseEntity.ok().body("Folders migrated successfully");
    }

    @Override
    public ResponseEntity<?> MigrateArticlesWithFilters(List<Filter> filters) {
        Query query = new Query();
        for (Filter filter : filters) {
            BiFunction<String, List<Object>, Criteria> criteriaFunction = criteriaMap.get(filter.getFilterType());
            if (criteriaFunction != null) {
                query.addCriteria(criteriaFunction.apply(filter.getField(), filter.getValues()));
            }
        }
        List<DumpedArticle> articles = mongoTemplate.find(query, DumpedArticle.class);  
        for (DumpedArticle article : articles) {
            migratedDataService.migrateArticle(article);
        }
        return ResponseEntity.ok().body("Articles migrated successfully");
    }

    
}
