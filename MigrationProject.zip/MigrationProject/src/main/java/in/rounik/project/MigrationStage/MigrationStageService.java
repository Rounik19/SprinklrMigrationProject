package in.rounik.project.MigrationStage;

import java.util.List;
import org.springframework.http.ResponseEntity;
import in.rounik.project.Filter.Filter;

public interface MigrationStageService {
    ResponseEntity<?> MigrateFoldersWithFilters(List<Filter> filters);
    ResponseEntity<?> MigrateArticlesWithFilters(List<Filter> filters);
}
