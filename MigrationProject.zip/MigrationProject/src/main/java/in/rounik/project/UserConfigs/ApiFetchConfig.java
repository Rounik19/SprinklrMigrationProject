package in.rounik.project.UserConfigs;

import java.util.Map;

public class ApiFetchConfig {
    private String Hostname;
    private String Path;
    private String Params;
    private String Headers;
    private HttpMethod Method;
    private Map<String, String> QueryParams;
    private Map<String, String> RequestHeaders;
    private String RequestBody;
    private AuthType AuthType;
    private String AuthToken;
    private int MaxRetries;
    private int RetryDelay;

    public enum HttpMethod {
        GET, POST, PUT, DELETE
    }

    public enum AuthType {
        NONE, BASIC, BEARER
    }

    public ApiFetchConfig() {
    }

    public ApiFetchConfig(String hostname, String path, String params, String headers, HttpMethod method, Map<String, String> queryParams, Map<String, String> requestHeaders, String requestBody, AuthType authType, String authToken, int maxRetries, int retryDelay) {
        Hostname = hostname;
        Path = path;
        Params = params;
        Headers = headers;
        Method = method;
        QueryParams = queryParams;
        RequestHeaders = requestHeaders;
        RequestBody = requestBody;
        AuthType = authType;
        AuthToken = authToken;
        MaxRetries = maxRetries;
        RetryDelay = retryDelay;
    }

    public String getHostname() {
        return Hostname;
    }

    public void setHostname(String hostname) {
        Hostname = hostname;
    }

    public String getPath() {
        return Path;
    }

    public void setPath(String path) {
        Path = path;
    }

    public String getParams() {
        return Params;
    }

    public void setParams(String params) {
        Params = params;
    }

    public String getHeaders() {
        return Headers;
    }

    public void setHeaders(String headers) {
        Headers = headers;
    }

    public HttpMethod getMethod() {
        return Method;
    }

    public void setMethod(HttpMethod method) {
        Method = method;
    }

    public Map<String, String> getQueryParams() {
        return QueryParams;
    }

    public void setQueryParams(Map<String, String> queryParams) {
        QueryParams = queryParams;
    }

    public Map<String, String> getRequestHeaders() {
        return RequestHeaders;
    }

    public void setRequestHeaders(Map<String, String> requestHeaders) {
        RequestHeaders = requestHeaders;
    }

    public String getRequestBody() {
        return RequestBody;
    }

    public void setRequestBody(String requestBody) {
        RequestBody = requestBody;
    }

    public AuthType getAuthType() {
        return AuthType;
    }

    public void setAuthType(AuthType authType) {
        AuthType = authType;
    }

    public String getAuthToken() {
        return AuthToken;
    }

    public void setAuthToken(String authToken) {
        AuthToken = authToken;
    }

    public int getMaxRetries() {
        return MaxRetries;
    }

    public void setMaxRetries(int maxRetries) {
        MaxRetries = maxRetries;
    }

    public int getRetryDelay() {
        return RetryDelay;
    }

    public void setRetryDelay(int retryDelay) {
        RetryDelay = retryDelay;
    }

}
