package in.rounik.project.DumpData;

import java.util.Date;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import in.rounik.project.KBObjects.KBFolder;

@Document(collection = "dumpedFolders")
public class DumpedFolder {
    @Id
    private String id;
    private Date fetchTime;
    private String fetchedFolder;
    private KBFolder folder;
    private boolean isDeleted;
    private boolean isMigrated;

    public DumpedFolder() {
    }

    public DumpedFolder(Date fetchTime, String fetchedFolder, KBFolder folder, boolean isDeleted, boolean isMigrated) {
        this.fetchTime = fetchTime;
        this.fetchedFolder = fetchedFolder;
        this.folder = folder;
        this.isDeleted = isDeleted;
        this.isMigrated = isMigrated;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Date getFetchTime() {
        return fetchTime;
    }

    public void setFetchTime(Date fetchTime) {
        this.fetchTime = fetchTime;
    }

    public String getFetchedFolder() {
        return fetchedFolder;
    }

    public void setFetchedFolder(String fetchedFolder) {
        this.fetchedFolder = fetchedFolder;
    }

    public KBFolder getFolder() {
        return folder;
    }

    public void setFolder(KBFolder folder) {
        this.folder = folder;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setDeleted(boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    public boolean isMigrated() {
        return isMigrated;
    }

    public void setMigrated(boolean isMigrated) {
        this.isMigrated = isMigrated;
    }

}