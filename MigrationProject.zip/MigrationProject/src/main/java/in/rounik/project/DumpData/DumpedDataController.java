package in.rounik.project.DumpData;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import in.rounik.project.Filter.Filter;

@RestController
public class DumpedDataController {

    @Autowired
    private DumpedDataService dumpedDataService;

    @GetMapping("/dumpedFolders/count")
    public ResponseEntity<?> getFoldersCount() {
        long count = dumpedDataService.getFoldersCount();
        return ResponseEntity.ok().body(count);
    }

    @GetMapping("/dumpedFolders/{id}")
    public ResponseEntity<?> getFolderById(@PathVariable String id) {
        DumpedFolder folder = dumpedDataService.getFolderById(id);
        if (folder != null) {
            return ResponseEntity.ok().body(folder);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/dumpedFolders/{id}")
    public ResponseEntity<?> deleteFolder(@PathVariable String id) {
        boolean isDeleted = dumpedDataService.deleteFolder(id);
        if (isDeleted) {
            return ResponseEntity.ok().body("Folder deleted successfully");
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/dumpedFolders")
    public ResponseEntity<?> deleteAllFolders() {
        dumpedDataService.deleteAllFolders();
        return ResponseEntity.ok().body("All folders deleted successfully");
    }

    @PostMapping("/dumpedFolders")
    public ResponseEntity<?> saveFolder(@RequestBody DumpedFolder dumpedFolder) {
        dumpedDataService.saveFolder(dumpedFolder);
        return ResponseEntity.ok().body("Folder saved successfully");
    }

    @GetMapping("/dumpedArticles/count")
    public ResponseEntity<?> getArticlesCount() {
        long count = dumpedDataService.getArticlesCount();
        return ResponseEntity.ok().body(count);
    }

    @GetMapping("/dumpedArticles/{id}")
    public ResponseEntity<?> getArticleById(@PathVariable String id) {
        DumpedArticle article = dumpedDataService.getArticleById(id);
        if (article != null) {
            return ResponseEntity.ok().body(article);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/dumpedArticles/{id}")
    public ResponseEntity<?> deleteArticle(@PathVariable String id) {
        boolean isDeleted = dumpedDataService.deleteArticle(id);
        if (isDeleted) {
            return ResponseEntity.ok().body("Article deleted successfully");
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/dumpedArticles")
    public ResponseEntity<?> deleteAllArticles() {
        dumpedDataService.deleteAllArticles();
        return ResponseEntity.ok().body("All articles deleted successfully");
    }

    @PostMapping("/dumpedArticles")
    public ResponseEntity<?> saveArticle(@RequestBody DumpedArticle dumpedArticle) {
        dumpedDataService.saveArticle(dumpedArticle);
        return ResponseEntity.ok().body("Article saved successfully");
    }

    @GetMapping("/dumpedFolders")
    public ResponseEntity<?> getFilteredFolders(@RequestBody(required = false) List<Filter> filters,
                                                @RequestParam(value = "page", defaultValue = "0") int page,
                                                @RequestParam(value = "size", defaultValue = "10") int size) {
        if (filters == null) {
            filters = List.of();
        }                                            
        Pageable pageable = PageRequest.of(page, size);
        Page<DumpedFolder> folders = dumpedDataService.getFilteredPagedFolders(filters, pageable);
        return ResponseEntity.ok().body(folders);
    }

    @GetMapping("/dumpedArticles")
    public ResponseEntity<?> getFilteredArticles(@RequestBody(required = false) List<Filter> filters,
                                                 @RequestParam(value = "page", defaultValue = "0") int page,
                                                 @RequestParam(value = "size", defaultValue = "10") int size) {
                                                    
        if (filters == null) {
            filters = List.of();
        }
        Pageable pageable = PageRequest.of(page, size);
        Page<DumpedArticle> articles = dumpedDataService.getFilteredPagedArticles(filters, pageable);
        return ResponseEntity.ok().body(articles);
    }
}
