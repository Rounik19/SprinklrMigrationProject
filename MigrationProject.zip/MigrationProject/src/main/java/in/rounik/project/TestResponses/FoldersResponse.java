package in.rounik.project.TestResponses;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "FoldersResponse")
public class FoldersResponse {
    @Id
    String id;
    String jsonResponse;

    public FoldersResponse() {
    }

    public FoldersResponse(String id, String jsonResponse) {
        this.id = id;
        this.jsonResponse = jsonResponse;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getJsonResponse() {
        return jsonResponse;
    }

    public void setJsonResponse(String jsonResponse) {
        this.jsonResponse = jsonResponse;
    }
}
