package in.rounik.project.UserConfigs;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ConfigsServiceImpl implements ConfigsService {

    @Autowired
    private ConfigsRepository configsRepository;

    @Override
    public List<Config> getAllConfigs() {
        return configsRepository.findAll();
    }

    @Override
    public Config getConfigById(String id) {
        return configsRepository.findById(id).orElse(null);
    }

    @Override
    public boolean addConfig(Config config) {
        try {
            configsRepository.save(config);
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

    @Override
    public boolean updateConfig(String id, Config config) {
        if (configsRepository.existsById(id)) {
            config.setId(id);
            configsRepository.deleteById(id);
            configsRepository.save(config);
            return true;
        }
        return false;
    }

    @Override
    public boolean deleteConfigById(String id) {
        if (configsRepository.existsById(id)) {
            configsRepository.deleteById(id);
            return true;
        }
        return false;
    }

    @Override
    public void deleteAllConfigs() {
        configsRepository.deleteAll();
    }

    @Override
    public long countConfigs() {
        return configsRepository.count();
    }
}
