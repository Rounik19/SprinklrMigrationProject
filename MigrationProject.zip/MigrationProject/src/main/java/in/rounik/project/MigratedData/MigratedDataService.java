package in.rounik.project.MigratedData;

import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import in.rounik.project.DumpData.DumpedArticle;
import in.rounik.project.DumpData.DumpedFolder;
import in.rounik.project.Filter.Filter;
import in.rounik.project.KBObjects.KBArticle;
import in.rounik.project.KBObjects.KBFolder;

public interface MigratedDataService {
    Page<KBFolder> getPagedFolders(Pageable pageable);
    long getFoldersCount();
    KBFolder getFolderById(String id);
    boolean deleteFolder(String id);
    void deleteAllFolders();
    void migrateFolder(DumpedFolder dunpedFolder);
    void saveFolder(KBFolder kbFolder);

    Page<KBArticle> getPagedArticles(Pageable pageable);
    long getArticlesCount();
    KBArticle getArticleById(String id);
    boolean deleteArticle(String id);
    void deleteAllArticles();
    void migrateArticle(DumpedArticle KbArticle);
    void saveArticle(KBArticle kbArticle);

    Page<KBFolder> getFilteredPagedFolders(List<Filter> filters, Pageable pageable);
    Page<KBArticle> getFilteredPagedArticles(List<Filter> filters, Pageable pageable);    
}
