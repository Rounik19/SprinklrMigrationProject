package in.rounik.project.DumpStage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import in.rounik.project.TestResponses.ArticlesResponse;
import in.rounik.project.TestResponses.FoldersResponse;
import in.rounik.project.DumpData.DumpedArticle;
import in.rounik.project.DumpData.DumpedDataService;
import in.rounik.project.DumpData.DumpedFolder;
import in.rounik.project.KBObjects.KBArticle;
import in.rounik.project.KBObjects.KBFolder;
import in.rounik.project.KBObjects.MigrationDetails;
import in.rounik.project.TestResponses.ResponseService;
import in.rounik.project.TestResponses.TranslationsResponse;
import in.rounik.project.UserConfigs.Config;
import in.rounik.project.UserConfigs.ConfigsService;
import in.rounik.project.UserConfigs.MappingConfiguration;
import in.rounik.project.UserConfigs.TransformationConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.RestTemplate;
import java.util.Date;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class DumpStageServiceImpl implements DumpStageService {

    @Autowired
    private ConfigsService configsService;
    
    @Autowired
    private DumpedDataService dumpedDataService;

    @Autowired
    private MappingService mappingService;

    @Autowired
    private UserScriptingService userScriptingService;

    @Autowired
    private ResponseService responseService;

    @Autowired
    private RestTemplate restTemplate;

    private static final Logger logger = LogManager.getLogger(DumpStageServiceImpl.class);

    private static RateLimiter rateLimiter;

    private String ConvertToJsonString(Object data) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            return objectMapper.writeValueAsString(data);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public ResponseEntity<?> getDump(String configId) {
        Config config = configsService.getConfigById(configId);
        if (config == null) {
            return ResponseEntity.status(404).body("Config not found");
        }

        // Initialize the rate limiter
        if(config.getMaxRequestsPerMinute() > 0){
            rateLimiter = new RateLimiter(config.getMaxRequestsPerMinute());
        }
        else{
            rateLimiter = new RateLimiter(60);
        }

        List<Object> finalData = new ArrayList<>();
        ObjectMapper objectMapper = new ObjectMapper();

        PaginationInfo paginationInfo = new PaginationInfo(1, 0, true, 0);

        while (paginationInfo.isHasMoreFolders()) {
            // first fetch folders
            try {
                fetchFolders(config, paginationInfo, finalData, objectMapper);
            } catch (Exception e) {
                logger.error("Error fetching folders: " + e.getMessage());
                return ResponseEntity.status(500).body("Error fetching folders: " + e.getMessage());
            }

            // now fetch articles
            try {
                fetchArticles(config, finalData);
            } catch (Exception e) {
                return ResponseEntity.status(500).body("Error fetching articles: " + e.getMessage());
            }

            // now fetch translations
            try {
                fetchTranslations(config, finalData);
            } catch (Exception e) {
                return ResponseEntity.status(500).body("Error fetching translations: " + e.getMessage());
            }
        }

        return ResponseEntity.ok("Dumped data successfully saved to the database\n");
    }

    private List<JsonNode> processJsonNodes(JsonNode jsonResponse, String path) {
        List<JsonNode> folderList = new ArrayList<>();
        JsonNode foldersNode = jsonResponse.at("/" + path);
        if (!foldersNode.isMissingNode()) {
            if (foldersNode.isArray()) {
                foldersNode.forEach(folderList::add);
            } else {
                folderList.add(foldersNode);
            }
        } else {
            folderList.add(jsonResponse);
        }
        return folderList;
    }

    private void fetchFolders(Config config, PaginationInfo paginationInfo, List<Object> finalData, ObjectMapper objectMapper) throws Exception {
        // ResponseEntity<String> response = fetchFoldersResponse(config, page, offset);

        // to test the code, we will use a hardcoded response
        String configId = config.getId();
        FoldersResponse foldersResponse = responseService.getFolderResponse(configId);
        String response = foldersResponse.getJsonResponse();
        JsonNode rootNode = objectMapper.readTree(response);
        String path = config.getFolderFetchConfig().getFoldersPath();
        List<JsonNode> folderNodes = processJsonNodes(rootNode, path);
        if(!folderNodes.isEmpty()){
            processFolders(folderNodes, config, finalData);
            if(config.getFolderFetchConfig().getPaginationConfig().getPageParam() != null){
                paginationInfo.setPage(paginationInfo.getPage() + 1);
            }
            else if (config.getFolderFetchConfig().getPaginationConfig().getOffsetParam() != null){
                paginationInfo.setOffset(paginationInfo.getOffset() + config.getFolderFetchConfig().getPaginationConfig().getPageSize());
            }
        }
        else{
            paginationInfo.setHasMoreFolders(false);
        }
        paginationInfo.setCnt(paginationInfo.getCnt() + folderNodes.size());
        if (paginationInfo.getCnt() > 0){
            paginationInfo.setHasMoreFolders(false);
        }
    }

    private void processFolders(List<JsonNode> folderNodes, Config config, List<Object> finalData) {
        for (JsonNode folderNode : folderNodes) {
            processSingleFolder(folderNode, config, finalData);
        }
    }

    private void processSingleFolder(JsonNode folderNode, Config config, List<Object> finalData) {
        List<String> requiredFieldValues = extractFieldIds(folderNode, config.getArticleFetchConfig().getNestedFieldPath().replace(config.getArticleFetchConfig().getNestedPathSeparator(), "/"), config.getArticleFetchConfig().getFieldParamPaths(), config.getArticleFetchConfig().getFieldParamRegex());
        logger.info("Required field values for fetching articles : " + requiredFieldValues);
        Map<String, Object> orderedMap = new LinkedHashMap<>();
        orderedMap.put("fetchedFolder", folderNode);
        orderedMap.put("requiredFieldValues", requiredFieldValues);
        finalData.add(orderedMap);


        // add dumped folder to the database
        DumpedFolder dumpedFolder = new DumpedFolder();
        dumpedFolder.setFetchTime(new Date());
        String jsonString = ConvertToJsonString(folderNode);
        dumpedFolder.setFetchedFolder(jsonString);
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        MappingConfiguration mappingConfiguration = config.getFolderFetchConfig().getMappingConfigurations();
        List<TransformationConfig> transformationConfigs = config.getFolderFetchConfig().getTransformations();
        ObjectNode transformedFolder = mappingService.executeDataTransformationScript(jsonString, mappingConfiguration);
        userScriptingService.transformData(folderNode, transformationConfigs, transformedFolder);
        KBFolder folder = objectMapper.convertValue(transformedFolder, KBFolder.class);
        MigrationDetails migrationDetails = new MigrationDetails();
        migrationDetails.setMigratedFrom("Freshdesk");
        migrationDetails.setMigratedId(folder.getFolderId());
        folder.setMigrationDetails(migrationDetails);
        dumpedFolder.setFolder(folder);
        dumpedDataService.saveFolder(dumpedFolder);
    }

    private List<String> extractFieldIds(JsonNode dataNode, String nestedPath, List<String> fieldParamValues, String regex) {
        List<String> fieldIds = new ArrayList<>();
        if(nestedPath == "" || nestedPath == null){
            logger.warn("Nested path is empty");
            return fieldIds;
        }
        String[] nestedPaths = nestedPath.split("/");
        performDFS(dataNode, nestedPaths, 0, fieldParamValues, fieldIds, regex);
        return fieldIds;
    }
    
    private void performDFS(JsonNode currentNode, String[] nestedPaths, int currentIndex, List<String> fieldParamValues, List<String> fieldIds, String regex) {
        if (currentIndex == nestedPaths.length) {
            JsonNode fieldNode = currentNode;
            List<String> fieldId = extractFieldId(fieldNode, fieldParamValues, regex);
            if(!fieldId.isEmpty()){
                fieldIds.addAll(fieldId);
            }
            return;
        }
        List<JsonNode> nextNodes = processJsonNodes(currentNode, nestedPaths[currentIndex]);
        for (JsonNode nxtNode : nextNodes) {
            performDFS(nxtNode, nestedPaths, currentIndex + 1, fieldParamValues, fieldIds, regex);
        }
    }

    private List<String> extractFieldId(JsonNode fieldNode, List<String> fieldParamValues, String regex) {
        List<String> fieldIds = new ArrayList<>();
        if(fieldParamValues != null && !fieldParamValues.isEmpty()){
            for (String idPath : fieldParamValues) {
                JsonNode idNode = fieldNode.at("/" + idPath);
                if (!idNode.isMissingNode()) {
                    String idValue = idNode.asText();
                    if (regex != null && !regex.isEmpty()) {
                        Matcher matcher = Pattern.compile(regex).matcher(idValue);
                        if (matcher.find()) {
                            idValue = matcher.group(1);
                        }
                    }
                    fieldIds.add(idValue);
                }
            }
            return fieldIds;
        }
        // field node is an array or simple json object, add all those values to the list
        if(fieldNode.isArray()){
            for(JsonNode node : fieldNode){
                fieldIds.add(node.asText());
            }
        }
        else{
            fieldIds.add(fieldNode.asText());
        }
        return fieldIds;
    }

    private ResponseEntity<String> fetchFoldersResponse(Config config, int page, int offset) {
        try {
            rateLimiter.acquire();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        String url = constructFolderFetchUrl(config, page, offset);
        HttpHeaders headers = constructHeaders(config);
        HttpEntity<String> entity = new HttpEntity<>(headers);
        return restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
    }

    private String constructFolderFetchUrl(Config config, int page, int offset) {
        StringBuilder url = new StringBuilder(config.getFolderFetchConfig().getApiFetchConfig().getHostname() + config.getFolderFetchConfig().getApiFetchConfig().getPath() + "?");
        if (config.getFolderFetchConfig().getPaginationConfig().getPageParam() != null) {
            url.append(config.getFolderFetchConfig().getPaginationConfig().getPageParam()).append("=").append(page).append("&");
        }

        if (config.getFolderFetchConfig().getPaginationConfig().getPageSizeParam() != null) {
            url.append(config.getFolderFetchConfig().getPaginationConfig().getPageSizeParam()).append("=").append(config.getFolderFetchConfig().getPaginationConfig().getPageSize()).append("&");
        }

        if (config.getFolderFetchConfig().getPaginationConfig().getOffsetParam() != null) {
            url.append(config.getFolderFetchConfig().getPaginationConfig().getOffsetParam()).append("=").append(offset).append("&");
        }

        return url.toString();
    }

    private void fetchArticles(Config config, List<Object> finalData) throws Exception {
        for (Object folderData : finalData) {
            if (folderData instanceof Map) {
                Map<String, Object> folderMap = (Map<String, Object>) folderData;
                List<String> requiredFieldValues = (List<String>) folderMap.get("requiredFieldValues");
                // remove the field values from the map
                folderMap.remove("requiredFieldValues");
                for (String fieldId : requiredFieldValues) {
                    fetchArticle(folderMap, fieldId, config);
                }
            }
        }
    }

    private void fetchArticle(Map<String, Object> folderMap, String fieldId, Config config) {
        // ResponseEntity<String> response = fetchArticleResponse(config, fieldId);

        // we use a hardcoded response to test the code
        String configId = config.getId();
        ArticlesResponse articlesResponse = responseService.getArticleResponse(configId);
        String response = articlesResponse.getJsonResponse();
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        try {
            JsonNode articlesNode = objectMapper.readTree(response);
            List<JsonNode> articles = processJsonNodes(articlesNode, config.getArticleFetchConfig().getArticlesPath());
            folderMap.put("FolderArticles", articles);

            // save the dumped article to the database(but before saving check if we have already saved this article)
            for(JsonNode article : articles){
                DumpedArticle dumpedArticle = new DumpedArticle();
                dumpedArticle.setFetchTime(new Date());
                String jsonString = ConvertToJsonString(article);
                dumpedArticle.setFetchedArticle(jsonString);
                MappingConfiguration mappingConfiguration = config.getArticleFetchConfig().getMappingConfigurations();
                ObjectNode transformedArticle = mappingService.executeDataTransformationScript(jsonString, mappingConfiguration);
                userScriptingService.transformData(article, config.getArticleFetchConfig().getTransformations(), transformedArticle);
                KBArticle kbArticle = objectMapper.convertValue(transformedArticle, KBArticle.class);
                MigrationDetails migrationDetails = new MigrationDetails();
                migrationDetails.setMigratedFrom("Freshdesk");
                migrationDetails.setMigratedId(kbArticle.getArticleId());
                kbArticle.setMigrationDetails(migrationDetails);
                dumpedArticle.setArticle(kbArticle);
                dumpedDataService.saveArticle(dumpedArticle);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private ResponseEntity<String> fetchArticleResponse(Config config, String fieldId) {
        try {
            rateLimiter.acquire();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        StringBuilder url = new StringBuilder(config.getArticleFetchConfig().getApiFetchConfig().getHostname() + config.getArticleFetchConfig().getApiFetchConfig().getPath() + "?");
        if (fieldId != null) {
            url.append(config.getArticleFetchConfig().getFieldParam()).append("=").append(fieldId).append("&");
        }
        HttpHeaders headers = constructHeaders(config);
        HttpEntity<String> entity = new HttpEntity<>(headers);
        return restTemplate.exchange(url.toString(), HttpMethod.GET, entity, String.class);
    }

    private HttpHeaders constructHeaders(Config config) {
        HttpHeaders headers = new HttpHeaders();
        if (config.getFolderFetchConfig().getApiFetchConfig().getRequestHeaders() != null) {
            config.getFolderFetchConfig().getApiFetchConfig().getRequestHeaders().forEach(headers::set);
        }

        if (config.getFolderFetchConfig().getApiFetchConfig().getAuthToken() != null) {
            headers.set("Authorization", "Bearer " + config.getFolderFetchConfig().getApiFetchConfig().getAuthToken());
        }

        return headers;
    }

    private void fetchTranslations(Config config, List<Object> finalData) throws Exception {
        for (Object folderData : finalData) {
            if (folderData instanceof Map) {
                Map<String, Object> folderMap = (Map<String, Object>) folderData;
                if (folderMap.containsKey("FolderArticles")) {
                    List<JsonNode> articles = (List<JsonNode>) folderMap.get("FolderArticles");
                    for (JsonNode article : articles) {
                        fetchTranslation(article, config);
                    }
                }
            }
        }
    }

    private void fetchTranslation(JsonNode article, Config config) {
        String uniqueIdentifierParam = config.getTranslationFetchConfig().getUniqueIdentifierParam();
        String uniqueIdentifierPath = config.getTranslationFetchConfig().getUniqueIdentifierPath();
        String uniqueIdentifierValue = article.at("/" + uniqueIdentifierPath).asText();
        List<String> languageCodes = config.getTranslationFetchConfig().getLanguageCodes();
        if(config.getTranslationFetchConfig().getLanguageVariantCommonPath() != null){
            String languageVariantCommonPath = config.getTranslationFetchConfig().getLanguageVariantCommonPath();
            String languageVariantPathSeparator = config.getTranslationFetchConfig().getLanguageVariantPathSeparator();
            if(languageVariantPathSeparator != null && !languageVariantPathSeparator.isEmpty()){
                languageVariantCommonPath = languageVariantCommonPath.replace(languageVariantPathSeparator, "/");
            }
            List<String> languageVariantFields = config.getTranslationFetchConfig().getLanguageVariantFields();
            String languageVariantFieldRegex = config.getTranslationFetchConfig().getLanguageVariantFieldRegex();
            languageCodes = extractFieldIds(article, languageVariantCommonPath, languageVariantFields, languageVariantFieldRegex);
        }
        logger.info("Required language codes for fetching translations : " + languageCodes);
        for(String languageCode : languageCodes){
            JsonNode translationsNode = fetchTranslationForParam(config, uniqueIdentifierParam, uniqueIdentifierValue, languageCode);
            ObjectMapper objectMapper = new ObjectMapper();
            DumpedArticle dumpedArticle = new DumpedArticle();
            dumpedArticle.setFetchTime(new Date());
            String jsonString = ConvertToJsonString(translationsNode);
            dumpedArticle.setFetchedArticle(jsonString);
            MappingConfiguration mappingConfiguration = config.getArticleFetchConfig().getMappingConfigurations();
            ObjectNode transformedArticle = mappingService.executeDataTransformationScript(jsonString, mappingConfiguration);
            userScriptingService.transformData(translationsNode, config.getArticleFetchConfig().getTransformations(), transformedArticle);
            KBArticle kbArticle = objectMapper.convertValue(transformedArticle, KBArticle.class);
            MigrationDetails migrationDetails = new MigrationDetails();
            migrationDetails.setMigratedFrom("Freshdesk");
            migrationDetails.setMigratedId(kbArticle.getArticleId());
            kbArticle.setMigrationDetails(migrationDetails);
            dumpedArticle.setArticle(kbArticle);
            dumpedDataService.saveArticle(dumpedArticle);
        }
    }

    private JsonNode fetchTranslationForParam(Config config, String uniqueIdentifierParam, String uniqueIdentifierValue, String languageCode) {
        // ResponseEntity<String> response = fetchTranslationResponse(config, articleId, translationParamValue, translationField);

        // we use a hardcoded response to test the code
        String configId = config.getId();
        TranslationsResponse translationResponse = responseService.getTranslationResponse(configId);
        String response = translationResponse.getJsonResponse();
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            JsonNode translationNode = objectMapper.readTree(response);
            return translationNode;
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return JsonNodeFactory.instance.objectNode();
    }

    private ResponseEntity<String> fetchTranslationResponse(Config config, String uniqueIdentifierParam, String uniqueIdentifierValue, String languageCode) {
        try {
            rateLimiter.acquire();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        // use the same api to fetch articles
        StringBuilder url = new StringBuilder(config.getArticleFetchConfig().getApiFetchConfig().getHostname() + config.getArticleFetchConfig().getApiFetchConfig().getPath() + "?");
        if (uniqueIdentifierParam != null) {
            url.append(uniqueIdentifierParam).append("=").append(uniqueIdentifierValue).append("&");
        }
        if(languageCode != null){
            url.append(config.getTranslationFetchConfig().getTranslationEndpointTemplate().replace("languageCode", languageCode));
        }
        HttpHeaders headers = constructHeaders(config);
        HttpEntity<String> entity = new HttpEntity<>(headers);
        return restTemplate.exchange(url.toString(), HttpMethod.GET, entity, String.class);
    }
}
