package in.rounik.project.DumpData;

import java.util.Date;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import in.rounik.project.KBObjects.KBArticle;

@Document(collection = "dumpedArticles")
public class DumpedArticle {
    @Id
    private String id;
    private Date fetchTime;
    private String fetchedArticle;
    private KBArticle article;
    private boolean isDeleted;
    private boolean isMigrated;
    
    public DumpedArticle() {
    }

    public DumpedArticle(Date fetchTime, String fetchedArticle, KBArticle article, boolean isDeleted, boolean isMigrated) {
        this.fetchTime = fetchTime;
        this.fetchedArticle = fetchedArticle;
        this.article = article;
        this.isDeleted = isDeleted;
        this.isMigrated = isMigrated;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Date getFetchTime() {
        return fetchTime;
    }

    public void setFetchTime(Date fetchTime) {
        this.fetchTime = fetchTime;
    }

    public String getFetchedArticle() {
        return fetchedArticle;
    }

    public void setFetchedArticle(String fetchedArticle) {
        this.fetchedArticle = fetchedArticle;
    }

    public KBArticle getArticle() {
        return article;
    }

    public void setArticle(KBArticle article) {
        this.article = article;
    }

    public boolean isDeleted() {
        return isDeleted;
    }

    public void setDeleted(boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    public boolean isMigrated() {
        return isMigrated;
    }

    public void setMigrated(boolean isMigrated) {
        this.isMigrated = isMigrated;
    }

}