package in.rounik.project.DumpStage;

import org.springframework.http.ResponseEntity;

public interface DumpStageService {
    ResponseEntity<?> getDump(String id);
}
