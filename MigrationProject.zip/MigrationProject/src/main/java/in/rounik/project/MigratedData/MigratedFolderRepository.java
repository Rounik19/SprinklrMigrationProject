package in.rounik.project.MigratedData;

import org.springframework.stereotype.Repository;
import in.rounik.project.KBObjects.KBFolder;

@Repository
public interface MigratedFolderRepository extends org.springframework.data.mongodb.repository.MongoRepository<KBFolder, String> {
    
}
