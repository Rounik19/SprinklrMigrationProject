package in.rounik.project.UserConfigs;
import java.util.List;

import in.rounik.project.DumpStage.PaginationConfig;

public class FolderFetchConfig {
    private ApiFetchConfig apiFetchConfig;
    private MappingConfiguration mappingConfigurations;
    private PaginationConfig paginationConfig;
    private List<TransformationConfig> transformations;

    // Folder-specific attributes
    private String foldersPath; // path to the field "folders" in the response(if response is a List of folders)
    private String folderIdPath; // path to the field "folder_id" inside a folder

    public FolderFetchConfig() {
    }

    public FolderFetchConfig(ApiFetchConfig apiFetchConfig, PaginationConfig paginationConfig, String foldersPath, String folderIdPath, MappingConfiguration mappingConfigurations, List<TransformationConfig> transformations) {
        this.apiFetchConfig = apiFetchConfig;
        this.paginationConfig = paginationConfig;
        this.foldersPath = foldersPath;
        this.folderIdPath = folderIdPath;
        this.mappingConfigurations = mappingConfigurations;
        this.transformations = transformations;
    }

    public ApiFetchConfig getApiFetchConfig() {
        return apiFetchConfig;
    }

    public void setApiFetchConfig(ApiFetchConfig apiFetchConfig) {
        this.apiFetchConfig = apiFetchConfig;
    }

    public PaginationConfig getPaginationConfig() {
        return paginationConfig;
    }

    public void setPaginationConfig(PaginationConfig paginationConfig) {
        this.paginationConfig = paginationConfig;
    }

    public String getFoldersPath() {
        return foldersPath;
    }

    public void setFoldersPath(String foldersPath) {
        this.foldersPath = foldersPath;
    }

    public String getFolderIdPath() {
        return folderIdPath;
    }

    public void setFolderIdPath(String folderIdPath) {
        this.folderIdPath = folderIdPath;
    }

    public MappingConfiguration getMappingConfigurations() {
        return mappingConfigurations;
    }

    public void setMappingConfigurations(MappingConfiguration mappingConfigurations) {
        this.mappingConfigurations = mappingConfigurations;
    }

    public List<TransformationConfig> getTransformations() {
        return transformations;
    }

}