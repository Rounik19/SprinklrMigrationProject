// // for testing the the Transformation function
// package in.rounik.project.DumpStage;

// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.http.HttpStatus;
// import org.springframework.http.ResponseEntity;
// import org.springframework.web.bind.annotation.*;
// import in.rounik.project.UserConfigs.MappingConfiguration;

// @RestController
// public class MappingController {

//     @Autowired
//     private MappingService MappingService;

//     @GetMapping("/testMapping/{type}")
//     public ResponseEntity<?> testMapping(@PathVariable int type) {
//         Object result = MappingService.executeDataTransformationScript("", new MappingConfiguration(), type);
//         return new ResponseEntity<>(result, HttpStatus.OK);
//     }
// }

