package in.rounik.project.UserConfigs;

import java.util.List;

public class TranslationFetchConfig {
    private List<String> languageCodes;
    private String uniqueIdentifierParam;
    private String uniqueIdentifierPath;
    private String languageVariantCommonPath;
    private String languageVariantPathSeparator;
    private List<String> languageVariantFields;
    private String languageVariantFieldRegex;
    private String translationEndpointTemplate;

    public TranslationFetchConfig() {
    }

    public TranslationFetchConfig(List<String> languageCodes, String uniqueIdentifierParam, String uniqueIdentifierPath, String languageVariantCommonPath, String languageVariantPathSeparator, List<String> languageVariantFields, String languageVariantFieldRegex, String translationEndpointTemplate) {
        this.languageCodes = languageCodes;
        this.uniqueIdentifierParam = uniqueIdentifierParam;
        this.uniqueIdentifierPath = uniqueIdentifierPath;
        this.languageVariantCommonPath = languageVariantCommonPath;
        this.languageVariantPathSeparator = languageVariantPathSeparator;
        this.languageVariantFields = languageVariantFields;
        this.languageVariantFieldRegex = languageVariantFieldRegex;
        this.translationEndpointTemplate = translationEndpointTemplate;  // Initialize new attribute
    }

    // Getters and setters for all attributes, including the new one
    public List<String> getLanguageCodes() {
        return languageCodes;
    }

    public void setLanguageCodes(List<String> languageCodes) {
        this.languageCodes = languageCodes;
    }

    public String getUniqueIdentifierParam() {
        return uniqueIdentifierParam;
    }

    public void setUniqueIdentifierParam(String uniqueIdentifierParam) {
        this.uniqueIdentifierParam = uniqueIdentifierParam;
    }

    public String getUniqueIdentifierPath() {
        return uniqueIdentifierPath;
    }

    public void setUniqueIdentifierPath(String uniqueIdentifierPath) {
        this.uniqueIdentifierPath = uniqueIdentifierPath;
    }

    public String getLanguageVariantCommonPath() {
        return languageVariantCommonPath;
    }

    public void setLanguageVariantCommonPath(String languageVariantCommonPath) {
        this.languageVariantCommonPath = languageVariantCommonPath;
    }

    public String getLanguageVariantPathSeparator() {
        return languageVariantPathSeparator;
    }

    public void setLanguageVariantPathSeparator(String languageVariantPathSeparator) {
        this.languageVariantPathSeparator = languageVariantPathSeparator;
    }

    public List<String> getLanguageVariantFields() {
        return languageVariantFields;
    }

    public void setLanguageVariantFields(List<String> languageVariantFields) {
        this.languageVariantFields = languageVariantFields;
    }

    public String getLanguageVariantFieldRegex() {
        return languageVariantFieldRegex;
    }

    public void setLanguageVariantFieldRegex(String languageVariantFieldRegex) {
        this.languageVariantFieldRegex = languageVariantFieldRegex;
    }

    public String getTranslationEndpointTemplate() {
        return translationEndpointTemplate;
    }

    public void setTranslationEndpointTemplate(String translationEndpointTemplate) {
        this.translationEndpointTemplate = translationEndpointTemplate;
    }
}