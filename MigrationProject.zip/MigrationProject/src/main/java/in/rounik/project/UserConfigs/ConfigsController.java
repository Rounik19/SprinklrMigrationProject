package in.rounik.project.UserConfigs;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ConfigsController {

    @Autowired
    private ConfigsService configsService;
    
    @GetMapping("/Configs")
    public ResponseEntity<?> getAllConfigs() {
        if (configsService.countConfigs() == 0) {
            return new ResponseEntity<>("No Configs found", HttpStatus.NOT_FOUND);
        }
        List<Config> configs = configsService.getAllConfigs();
        return new ResponseEntity<>(configs, HttpStatus.OK);
    }

    @GetMapping("/Configs/{id}")
    public ResponseEntity<?> getConfigById(@PathVariable String id) {
        Config config = configsService.getConfigById(id);
        if (config != null) {
            return new ResponseEntity<>(config, HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Config with id: " + id + " not found", HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/Configs")
    public ResponseEntity<String> addConfig(@RequestBody Config config) {
        boolean isAdded = configsService.addConfig(config);
        if (isAdded) {
            return new ResponseEntity<>("Config added successfully with id: " + config.getId(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Failed to add Config", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/Configs/{id}")
    public ResponseEntity<String> updateConfig(@RequestBody Config config, @PathVariable String id) {
        boolean isUpdated = configsService.updateConfig(id, config);
        if (isUpdated) {
            return new ResponseEntity<>("Config with id: " + id + " updated successfully", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Config with id: " + id + " not found", HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/Configs/{id}")
    public ResponseEntity<String> deleteConfigById(@PathVariable String id) {
        boolean isDeleted = configsService.deleteConfigById(id);
        if (isDeleted) {
            return new ResponseEntity<>("Config with id: " + id + " deleted successfully", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Config with id: " + id + " not found", HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/Configs")
    public ResponseEntity<String> deleteAllConfigs() {
        configsService.deleteAllConfigs();
        return new ResponseEntity<>("All Configs deleted successfully", HttpStatus.OK);
    }
}
