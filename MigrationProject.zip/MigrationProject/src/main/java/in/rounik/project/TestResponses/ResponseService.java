package in.rounik.project.TestResponses;

import java.util.List;

import org.springframework.http.ResponseEntity;

public interface ResponseService {

    List<FoldersResponse> getFoldersResponse();
    FoldersResponse getFolderResponse(String id);
    List<ArticlesResponse> getArticlesResponse();
    ArticlesResponse getArticleResponse(String id);
    List<TranslationsResponse> getTranslationsResponse();
    TranslationsResponse getTranslationResponse(String id);
    ResponseEntity<?> addFolderResponse(FoldersResponse foldersResponse);
    ResponseEntity<?> addArticleResponse(ArticlesResponse articlesResponse);
    ResponseEntity<?> addTranslationResponse(TranslationsResponse translationsResponse);
    ResponseEntity<?> deleteFolderResponse(String id);
    ResponseEntity<?> deleteArticleResponse(String id);
    ResponseEntity<?> deleteTranslationResponse(String id);
    ResponseEntity<?> deleteFoldersResponse();
    ResponseEntity<?> deleteArticlesResponse();
    ResponseEntity<?> deleteTranslationsResponse();
}

