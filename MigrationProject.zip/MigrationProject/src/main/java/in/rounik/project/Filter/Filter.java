package in.rounik.project.Filter;

import java.util.List;

public class Filter {
    private String field;
    private FilterType filterType;
    private List<Object> values;

    public Filter() {
    }

    public Filter(String field, FilterType filterType, List<Object> values) {
        this.field = field;
        this.filterType = filterType;
        this.values = values;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public FilterType getFilterType() {
        return filterType;
    }

    public void setFilterType(FilterType filterType) {
        this.filterType = filterType;
    }

    public List<Object> getValues() {
        return values;
    }

    public void setValues(List<Object> values) {
        this.values = values;
    }
}