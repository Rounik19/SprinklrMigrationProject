// ConfigsService.java
package in.rounik.project.UserConfigs;

import java.util.List;

public interface ConfigsService {

    List<Config> getAllConfigs();
    Config getConfigById(String id);
    boolean addConfig(Config config);
    boolean updateConfig(String id, Config config);
    boolean deleteConfigById(String id);
    void deleteAllConfigs();
    long countConfigs();
}
