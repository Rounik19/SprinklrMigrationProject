package in.rounik.project.UserConfigs;


import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document(collection = "Configs")
public class Config {
    @Id
    private String id;
    private FolderFetchConfig folderFetchConfig;
    private ArticleFetchConfig articleFetchConfig;
    private TranslationFetchConfig translationFetchConfig;
    private int maxRequestsPerMinute;


    public Config() {
    }

    public Config(String id, FolderFetchConfig folderFetchConfig, ArticleFetchConfig articleFetchConfig, TranslationFetchConfig translationFetchConfig, int maxRequestsPerMinute) {
        this.id = id;
        this.folderFetchConfig = folderFetchConfig;
        this.articleFetchConfig = articleFetchConfig;
        this.translationFetchConfig = translationFetchConfig;
        this.maxRequestsPerMinute = maxRequestsPerMinute;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public FolderFetchConfig getFolderFetchConfig() {
        return folderFetchConfig;
    }

    public void setFolderFetchConfig(FolderFetchConfig folderFetchConfig) {
        this.folderFetchConfig = folderFetchConfig;
    }

    public ArticleFetchConfig getArticleFetchConfig() {
        return articleFetchConfig;
    }

    public void setArticleFetchConfig(ArticleFetchConfig articleFetchConfig) {
        this.articleFetchConfig = articleFetchConfig;
    }

    public TranslationFetchConfig getTranslationFetchConfig() {
        return translationFetchConfig;
    }

    public void setTranslationFetchConfig(TranslationFetchConfig translationFetchConfig) {
        this.translationFetchConfig = translationFetchConfig;
    }

    public int getMaxRequestsPerMinute() {
        return maxRequestsPerMinute;
    }

    public void setMaxRequestsPerMinute(int maxRequestsPerMinute) {
        this.maxRequestsPerMinute = maxRequestsPerMinute;
    }
    
}