package in.rounik.project.DumpStage;

import java.time.Instant;
import java.util.concurrent.atomic.AtomicInteger;

public class RateLimiter {
    private final int maxRequestsPerMinute;
    private AtomicInteger requestCount;
    private Instant resetTime;

    public RateLimiter(int maxRequestsPerMinute) {
        this.maxRequestsPerMinute = maxRequestsPerMinute;
        this.requestCount = new AtomicInteger(0);
        this.resetTime = Instant.now().plusSeconds(60);
    }

    public synchronized void acquire() throws InterruptedException {
        Instant now = Instant.now();
        if (now.isAfter(resetTime)) {
            requestCount.set(0);
            resetTime = now.plusSeconds(60);
        }

        if (requestCount.incrementAndGet() > maxRequestsPerMinute) {
            long waitTime = resetTime.toEpochMilli() - now.toEpochMilli();
            Thread.sleep(waitTime);
            requestCount.set(0);
            resetTime = Instant.now().plusSeconds(60);
            requestCount.incrementAndGet();
        }
    }
}
