package in.rounik.project.DumpData;
import org.springframework.stereotype.Repository;

@Repository
public interface DumpedArticleRepository extends org.springframework.data.mongodb.repository.MongoRepository<DumpedArticle, String> {
    
}