package in.rounik.project.UserConfigs;

import java.util.Map;

public class MappingConfiguration {

    private Map<String, Object> configuration;

    public Map<String, Object> getConfiguration() {
        return configuration;
    }

    public void setConfiguration(Map<String, Object> configuration) {
        this.configuration = configuration;
    }
    
}
