package in.rounik.project.DumpStage;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import groovy.lang.GroovyClassLoader;
import in.rounik.project.UserConfigs.TransformationConfig;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class UserScriptingService {

    private final ObjectMapper objectMapper;

    private UserScriptingService() {
        this.objectMapper = new ObjectMapper();
    }

    public void transformData(JsonNode originalData, List<TransformationConfig> configs, ObjectNode transformedData) {
        // ObjectNode transformedData = objectMapper.createObjectNode();

        for (TransformationConfig config : configs) {
            List<JsonNode> sourceValues = new ArrayList<>();
            for (String sourcePath : config.getSourcePath()) {
                JsonNode sourceValue = originalData.at(sourcePath);
                if (!sourceValue.isMissingNode()) {
                    sourceValues.add(sourceValue);
                }
            }
            if(sourceValues.size() == 0 || sourceValues.contains(objectMapper.nullNode())) {
                continue;
            }
            try {
                JsonNode transformedValue = executeScript(config.getScript(), config.getMethodName(), sourceValues);
                insertValue(transformedData, config.getTargetPath(), transformedValue);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private JsonNode executeScript(String script, String methodName, List<JsonNode> sourceValues) throws IOException {
        GroovyClassLoader groovyClassLoader = new GroovyClassLoader();
        script = "import com.fasterxml.jackson.databind.JsonNode;\nimport java.util.List;\n" + script;
        Class<?> scriptClass = groovyClassLoader.parseClass(script);
        try {
            Object scriptInstance = scriptClass.getDeclaredConstructor().newInstance();
            Object result = scriptClass.getMethod(methodName, List.class).invoke(scriptInstance, sourceValues);
            return result != null ? objectMapper.valueToTree(result) : objectMapper.nullNode();
        } catch (Exception e) {
            throw new IOException("Failed to execute script", e);
        } finally {
            groovyClassLoader.close();
        }
    }

    private void insertValue(ObjectNode node, String path, JsonNode value) {
        String[] keys = path.split("/");
        ObjectNode currentNode = node;
        for (int i = 1; i < keys.length; i++) {
            String key = keys[i];
            if (i == keys.length - 1) {
                currentNode.set(key, value);
            } else {
                if (!currentNode.has(key) || !(currentNode.get(key) instanceof ObjectNode)) {
                    currentNode.set(key, objectMapper.createObjectNode());
                }
                currentNode = (ObjectNode) currentNode.get(key);
            }
        }
    }

    // public static void main(String[] args) throws IOException {
    //     ObjectMapper objectMapper = new ObjectMapper();
    //     ObjectNode transformedData = objectMapper.createObjectNode();
    //     // Sample original JSON data
    //     String originalJson = "{ \"name\": \"John\", \"age\": 30, \"city\": \"New York\", \"scores\": { \"math\": 85, \"english\": 90 }, \"items\": [\"apple\", \"banana\"] }";
    //     JsonNode originalData = objectMapper.readTree(originalJson);

    //     // Sample transformation configurations
    //     List<TransformationConfig> configs = new ArrayList<>();
        
    //     // Concatenate name and city into fullName
    //     configs.add(new TransformationConfig(
    //             List.of("/name", "/city"),
    //             "/fullName",
    //             "class TransformScript { String transform(List<JsonNode> sourceValues) { return sourceValues.get(0).asText() + ' from ' + sourceValues.get(1).asText(); } }",
    //             "transform"
    //     ));
        
    //     // Calculate total score from math and english scores
    //     configs.add(new TransformationConfig(
    //             List.of("/scores/math", "/scores/english"),
    //             "/totalScore",
    //             "class TransformScript { int transform(List<JsonNode> sourceValues) { return sourceValues.get(0).asInt() + sourceValues.get(1).asInt(); } }",
    //             "transform"
    //     ));
        
    //     // Create a description of favorite items
    //     configs.add(new TransformationConfig(
    //             List.of("/items"),
    //             "/itemDescription",
    //             "class TransformScript { String transform(List<JsonNode> sourceValues) { return 'Favorite items: ' + sourceValues.get(0).toString(); } }",
    //             "transform"
    //     ));
        
    //     // Transform a nested structure
    //     configs.add(new TransformationConfig(
    //             List.of("/name", "/age"),
    //             "/personalInfo",
    //             "class TransformScript { String transform(List<JsonNode> sourceValues) { return 'Name: ' + sourceValues.get(0).asText() + ', Age: ' + sourceValues.get(1).asInt(); } }",
    //             "transform"
    //     ));

    //     new UserScriptingService().transformData(originalData, configs, transformedData);
    //     System.out.println("trasnformedData: " + transformedData);
    // }

}
