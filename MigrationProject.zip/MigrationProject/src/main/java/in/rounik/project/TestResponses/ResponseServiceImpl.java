package in.rounik.project.TestResponses;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class ResponseServiceImpl implements ResponseService {
    
    @Autowired
    private ArticlesResponseRepository articlesResponseRepository;
    @Autowired
    private FoldersResponseRepository foldersResponseRepository;
    @Autowired
    private TranslationsResponseRepository translationsResponseRepository;

    @Override
    public List<FoldersResponse> getFoldersResponse() {
        return foldersResponseRepository.findAll();
    }
    
    @Override
    public FoldersResponse getFolderResponse(String id) {
        return foldersResponseRepository.findById(id).get();
    }

    @Override
    public List<ArticlesResponse> getArticlesResponse() {
        return articlesResponseRepository.findAll();
    }

    @Override
    public ArticlesResponse getArticleResponse(String id) {
        return articlesResponseRepository.findById(id).get();
    }

    @Override
    public List<TranslationsResponse> getTranslationsResponse() {
        return translationsResponseRepository.findAll();
    }

    @Override
    public TranslationsResponse getTranslationResponse(String id) {
        return translationsResponseRepository.findById(id).get();
    }

    @Override
    public ResponseEntity<?> addFolderResponse(FoldersResponse foldersResponse) {
        foldersResponseRepository.save(foldersResponse);
        return new ResponseEntity<>("Folder Response added successfully", HttpStatus.CREATED);
    }

    @Override
    public ResponseEntity<?> addArticleResponse(ArticlesResponse articlesResponse) {
        articlesResponseRepository.save(articlesResponse);
        return new ResponseEntity<>("Article Response added successfully", HttpStatus.CREATED);
    }

    @Override
    public ResponseEntity<?> addTranslationResponse(TranslationsResponse translationsResponse) {
        translationsResponseRepository.save(translationsResponse);
        return new ResponseEntity<>("Translation Response added successfully", HttpStatus.CREATED);
    }

    @Override
    public ResponseEntity<?> deleteFolderResponse(String id) {
        foldersResponseRepository.deleteById(id);
        return new ResponseEntity<>("Folder Response deleted successfully", HttpStatus.OK);
    }

    @Override
    public ResponseEntity<?> deleteArticleResponse(String id) {
        articlesResponseRepository.deleteById(id);
        return new ResponseEntity<>("Article Response deleted successfully", HttpStatus.OK);
    }

    @Override
    public ResponseEntity<?> deleteTranslationResponse(String id) {
        translationsResponseRepository.deleteById(id);
        return new ResponseEntity<>("Translation Response deleted successfully", HttpStatus.OK);
    }

    @Override
    public ResponseEntity<?> deleteFoldersResponse() {
        foldersResponseRepository.deleteAll();
        return new ResponseEntity<>("All Folder Responses deleted successfully", HttpStatus.OK);
    }

    @Override
    public ResponseEntity<?> deleteArticlesResponse() {
        articlesResponseRepository.deleteAll();
        return new ResponseEntity<>("All Article Responses deleted successfully", HttpStatus.OK);
    }

    @Override
    public ResponseEntity<?> deleteTranslationsResponse() {
        translationsResponseRepository.deleteAll();
        return new ResponseEntity<>("All Translation Responses deleted successfully", HttpStatus.OK);
    }

}