package in.rounik.project.TestResponses;

import org.springframework.stereotype.Repository;

@Repository
public interface TranslationsResponseRepository extends org.springframework.data.mongodb.repository.MongoRepository<TranslationsResponse, String> {
    
}
