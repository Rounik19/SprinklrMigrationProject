package in.rounik.project.TestResponses;

import org.springframework.stereotype.Repository;

@Repository
public interface FoldersResponseRepository extends org.springframework.data.mongodb.repository.MongoRepository<FoldersResponse, String> {
    
}
