package in.rounik.project.UserConfigs;

import java.util.List;

public class ArticleFetchConfig {
    private ApiFetchConfig apiFetchConfig;
    private String articlesPath; // path to the field "articles" in the response(if response is a List of articles)
    private String articleIdPath; // path to the field "article_id" inside an article
    private String fieldParam; // field parameter to be used(in the url) to fetch articles(eg. "folder_id", "article_id")
    private String nestedFieldPath; // path to the field : fieldParam(upto the level of nesting that is a list of JSONS)
    private String nestedPathSeparator; // separator used by user(eg. ".")
    private List<String> fieldParamPaths; // path to the FieldParam inside the nestedFieldPath
    private String fieldParamRegex; // regex to be used to extract the fieldParam from the fieldParamPath
    private MappingConfiguration mappingConfigurations;
    private List<TransformationConfig> transformations;

    public ArticleFetchConfig() {
    }

    public ArticleFetchConfig(ApiFetchConfig apiFetchConfig, String articlesPath, String articleIdPath, String nestedFieldPath, String fieldParam, String nestedPathSeparator, List<String> fieldParamPaths, String fieldParamRegex, MappingConfiguration mappingConfigurations, List<TransformationConfig> transformations) {
        this.apiFetchConfig = apiFetchConfig;
        this.articlesPath = articlesPath;
        this.articleIdPath = articleIdPath;
        this.nestedFieldPath = nestedFieldPath;
        this.fieldParam = fieldParam;
        this.nestedPathSeparator = nestedPathSeparator;
        this.fieldParamPaths = fieldParamPaths;
        this.fieldParamRegex = fieldParamRegex;
        this.mappingConfigurations = mappingConfigurations;
        this.transformations = transformations;
    }

    public ApiFetchConfig getApiFetchConfig() {
        return apiFetchConfig;
    }

    public void setApiFetchConfig(ApiFetchConfig apiFetchConfig) {
        this.apiFetchConfig = apiFetchConfig;
    }

    public String getArticlesPath() {
        return articlesPath;
    }

    public void setArticlesPath(String articlesPath) {
        this.articlesPath = articlesPath;
    }

    public String getArticleIdPath() {
        return articleIdPath;
    }

    public void setArticleIdPath(String articleIdPath) {
        this.articleIdPath = articleIdPath;
    }

    public String getNestedFieldPath() {
        return nestedFieldPath;
    }

    public void setNestedFieldPath(String nestedFieldPath) {
        this.nestedFieldPath = nestedFieldPath;
    }

    public String getFieldParam() {
        return fieldParam;
    }

    public void setFieldParam(String fieldParam) {
        this.fieldParam = fieldParam;
    }

    public String getNestedPathSeparator() {
        return nestedPathSeparator;
    }

    public void setNestedPathSeparator(String nestedPathSeparator) {
        this.nestedPathSeparator = nestedPathSeparator;
    }

    public List<String> getFieldParamPaths() {
        return fieldParamPaths;
    }

    public void setFieldParamPaths(List<String> fieldParamPaths) {
        this.fieldParamPaths = fieldParamPaths;
    }

    public String getFieldParamRegex() {
        return fieldParamRegex;
    }

    public void setFieldParamRegex(String fieldParamRegex) {
        this.fieldParamRegex = fieldParamRegex;
    }

    public MappingConfiguration getMappingConfigurations() {
        return mappingConfigurations;
    }

    public void setMappingConfigurations(MappingConfiguration mappingConfigurations) {
        this.mappingConfigurations = mappingConfigurations;
    }

    public List<TransformationConfig> getTransformations() {
        return transformations;
    }

    public void setTransformations(List<TransformationConfig> transformations) {
        this.transformations = transformations;
    }

}
