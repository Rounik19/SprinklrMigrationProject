package in.rounik.project.MigrationStage;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.rounik.project.Filter.Filter;

@RestController
@RequestMapping("/migrate")
public class MigrationStageController {

    @Autowired
    private MigrationStageService migrationStageService;

    @PostMapping("/folders")
    public ResponseEntity<?> migrateFoldersWithFilters(@RequestBody(required = false) List<Filter> filters) {
        if(filters == null)
            filters = List.of();
        return migrationStageService.MigrateFoldersWithFilters(filters);
    }

    @PostMapping("/articles")
    public ResponseEntity<?> migrateArticlesWithFilters(@RequestBody(required = false) List<Filter> filters) {
        if(filters == null)
            filters = List.of();
        return migrationStageService.MigrateArticlesWithFilters(filters);
    }
}
