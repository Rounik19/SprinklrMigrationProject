package in.rounik.project.TestResponses;

import org.springframework.stereotype.Repository;

@Repository
public interface ArticlesResponseRepository extends org.springframework.data.mongodb.repository.MongoRepository<ArticlesResponse, String> {
    
}
