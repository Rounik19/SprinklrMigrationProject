package in.rounik.project.TestResponses;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ResponseController {

    @Autowired
    private ResponseService responseService;
    
    @GetMapping("/FoldersResponse")
    public List<FoldersResponse> getFoldersResponse() {
        return responseService.getFoldersResponse();
    }

    @GetMapping("/FoldersResponse/{id}")
    public FoldersResponse getFolderResponse(@PathVariable String id) {
        return responseService.getFolderResponse(id);
    }

    @GetMapping("/ArticlesResponse")
    public List<ArticlesResponse> getArticlesResponse() {
        return responseService.getArticlesResponse();
    }

    @GetMapping("/ArticlesResponse/{id}")
    public ArticlesResponse getArticleResponse(@PathVariable String id) {
        return responseService.getArticleResponse(id);
    }

    @GetMapping("/TranslationsResponse")
    public List<TranslationsResponse> getTranslationsResponse() {
        return responseService.getTranslationsResponse();
    }

    @GetMapping("/TranslationsResponse/{id}")
    public TranslationsResponse getTranslationResponse(@PathVariable String id) {
        return responseService.getTranslationResponse(id);
    }

    @PostMapping("/FoldersResponse")
    public ResponseEntity<?> addFolderResponse(@RequestBody FoldersResponse foldersResponse) {
        return responseService.addFolderResponse(foldersResponse);
    }

    @PostMapping("/ArticlesResponse")
    public ResponseEntity<?> addArticleResponse(@RequestBody ArticlesResponse articlesResponse) {
        return responseService.addArticleResponse(articlesResponse);
    }

    @PostMapping("/TranslationsResponse")
    public ResponseEntity<?> addTranslationResponse(@RequestBody TranslationsResponse translationsResponse) {
        return responseService.addTranslationResponse(translationsResponse);
    }

    @DeleteMapping("/FoldersResponse/{id}")
    public ResponseEntity<?> deleteFolderResponse(@PathVariable String id) {
        return responseService.deleteFolderResponse(id);
    }

    @DeleteMapping("/ArticlesResponse/{id}")
    public ResponseEntity<?> deleteArticleResponse(@PathVariable String id) {
        return responseService.deleteArticleResponse(id);
    }

    @DeleteMapping("/TranslationsResponse/{id}")
    public ResponseEntity<?> deleteTranslationResponse(@PathVariable String id) {
        return responseService.deleteTranslationResponse(id);
    }

    @DeleteMapping("/FoldersResponse")
    public ResponseEntity<?> deleteFoldersResponse() {
        return responseService.deleteFoldersResponse();
    }

    @DeleteMapping("/ArticlesResponse")
    public ResponseEntity<?> deleteArticlesResponse() {
        return responseService.deleteArticlesResponse();
    }

    @DeleteMapping("/TranslationsResponse")
    public ResponseEntity<?> deleteTranslationsResponse() {
        return responseService.deleteTranslationsResponse();
    }


}