package in.rounik.project.DumpStage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DumpStageController {
    @Autowired
    private DumpStageService dumpStageService;

    @GetMapping("/dumpData/{id}")
    public ResponseEntity<?> dumpData(@PathVariable String id){
        return dumpStageService.getDump(id);
    }
}