package in.rounik.project.DumpData;

import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import in.rounik.project.Filter.Filter;

public interface DumpedDataService {

    long getFoldersCount();
    DumpedFolder getFolderById(String id);
    boolean deleteFolder(String id);
    void deleteAllFolders();
    void saveFolder(DumpedFolder dumpedFolder);

    long getArticlesCount();
    DumpedArticle getArticleById(String id);
    boolean deleteArticle(String id);
    void deleteAllArticles();
    void saveArticle(DumpedArticle dumpedArticle);

    Page<DumpedFolder> getFilteredPagedFolders(List<Filter> filters, Pageable pageable);
    Page<DumpedArticle> getFilteredPagedArticles(List<Filter> filters, Pageable pageable);
}
