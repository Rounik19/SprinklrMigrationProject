package in.rounik.project.Filter;

public enum FilterType {
    EQUAL,
    NOT_EQUAL,
    GT,
    GTE,
    LT,
    LTE,
    CONTAINING,
    NOT_CONTAINING,
    BETWEEN,
    IN,
    NOT_IN
}
