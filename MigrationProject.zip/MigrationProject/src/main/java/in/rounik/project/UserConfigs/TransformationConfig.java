package in.rounik.project.UserConfigs;

import java.util.List;

public class TransformationConfig {
    private List<String> sourcePath;
    private String targetPath;
    private String script;
    private String methodName;

    public TransformationConfig() {
    }

    public TransformationConfig(List<String> sourcePath, String targetPath, String script, String methodName) {
        this.sourcePath = sourcePath;
        this.targetPath = targetPath;
        this.script = script;
        this.methodName = methodName;
    }

    public List<String> getSourcePath() {
        return sourcePath;
    }

    public void setSourcePath(List<String> sourcePath) {
        this.sourcePath = sourcePath;
    }

    public String getTargetPath() {
        return targetPath;
    }

    public void setTargetPath(String targetPath) {
        this.targetPath = targetPath;
    }

    public String getScript() {
        return script;
    }

    public void setScript(String script) {
        this.script = script;
    }

    public String getMethodName() {
        return methodName;
    }

    public void setMethodName(String methodName) {
        this.methodName = methodName;
    }

}
