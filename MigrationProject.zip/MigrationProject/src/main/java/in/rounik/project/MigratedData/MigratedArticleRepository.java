package in.rounik.project.MigratedData;

import org.springframework.stereotype.Repository;
import in.rounik.project.KBObjects.KBArticle;

@Repository
public interface MigratedArticleRepository extends org.springframework.data.mongodb.repository.MongoRepository<KBArticle, String> {
    
}
