package in.rounik.project.DumpStage;

import in.rounik.project.UserConfigs.MappingConfiguration;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.io.IOException;
import java.util.Map;


@Service
public class MappingService {

    public ObjectNode executeDataTransformationScript(String jsonString, MappingConfiguration mappingConfiguration){
        // System.out.println("MappingConfiguration: " + mappingConfiguration);
        return processDataNode(ConvertStringToJsonNode(jsonString), mappingConfiguration.getConfiguration());
    }

    JsonNode ConvertStringToJsonNode(String fetchedData) {
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode rootNode = null;
        try {
            rootNode = objectMapper.readTree(fetchedData);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return rootNode;
    }

    ObjectNode processDataNode(JsonNode dataNode, Map<String, Object> mappingConfiguration) {
        ObjectMapper objectMapper = new ObjectMapper();
        ObjectNode transformedData = objectMapper.createObjectNode();
        mappingConfiguration.forEach((key, value) -> {
            dataNode.fields().forEachRemaining(entry -> {
                if(entry.getKey().equals(key)) {
                    if(value instanceof String) {
                        ( transformedData).set((String) value, entry.getValue());
                    }
                    else if(value instanceof Map) {
                        if(entry.getValue() instanceof ArrayNode) {
                            @SuppressWarnings("unchecked")
                            String target = (String) ((Map<String, Object>) value).get("target");
                            @SuppressWarnings("unchecked")
                            Map<String, Object> transform = (Map<String, Object>) ((Map<String, Object>) value).get("transform");
                            ArrayNode arrayNode = objectMapper.createArrayNode();
                            ((ArrayNode) entry.getValue()).forEach(node -> {
                                JsonNode transformedNode = processDataNode(node, transform);
                                arrayNode.add(transformedNode);
                            });
                            ((ObjectNode) transformedData).set(target, arrayNode);
                        }
                        else { // it is a Json object
                            @SuppressWarnings("unchecked")
                            String target = (String) ((Map<String, Object>) value).get("target");
                            @SuppressWarnings("unchecked")
                            Map<String, Object> transform = (Map<String, Object>) ((Map<String, Object>) value).get("transform");
                            JsonNode transformedNode = processDataNode(entry.getValue(), transform);
                            if(!target.equals("")) {
                                ((ObjectNode) transformedData).set(target, transformedNode);
                            }
                            else {
                                // Add all the fields of transformedNode to transformedData
                                transformedNode.fields().forEachRemaining(field -> {
                                    ((ObjectNode) transformedData).set(field.getKey(), field.getValue());
                                });
                            }
                        }
                    }
                }
            });
        });
        return transformedData;
    }

}