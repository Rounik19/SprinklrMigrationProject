package in.rounik.project.KBObjects;

import java.util.Date;
import java.util.List;
import java.util.Map;

public class KBArticle {
    //data fields
    private String articleId;
    private String title;
    private String content;
    private String ParentFolderId;
    private String description;
    private List<String> tags;
    private boolean favorite;
    private boolean deleted;
    private Date createdAt;
    private String createdBy;
    private String lastModifiedBy;
    private Date lastModifiedTime;

    //stats
    private int viewCount;
    private int helpfulCount;
    private int notHelpfulCount;
    private int rating;

    //locale / language
    private String locale;
    private String baseLngArticleId;
    private Map<String, String> lngVariants;

    // Migration details
    private MigrationDetails migrationDetails;

    public KBArticle() {
    }

    public KBArticle(String articleId, String title, String content, String parentFolderId, String description, List<String> tags, boolean favorite, boolean deleted, Date createdAt, String createdBy, String lastModifiedBy, Date lastModifiedTime, int viewCount, int helpfulCount, int notHelpfulCount, int rating, String locale, String baseLngArticleId, Map<String, String> lngVariants, MigrationDetails migrationDetails) {
        this.articleId = articleId;
        this.title = title;
        this.content = content;
        this.ParentFolderId = parentFolderId;
        this.description = description;
        this.tags = tags;
        this.favorite = favorite;
        this.deleted = deleted;
        this.createdAt = createdAt;
        this.createdBy = createdBy;
        this.lastModifiedBy = lastModifiedBy;
        this.lastModifiedTime = lastModifiedTime;
        this.viewCount = viewCount;
        this.helpfulCount = helpfulCount;
        this.notHelpfulCount = notHelpfulCount;
        this.rating = rating;
        this.locale = locale;
        this.baseLngArticleId = baseLngArticleId;
        this.lngVariants = lngVariants;
        this.migrationDetails = migrationDetails;
    }

    public String getArticleId() {
        return articleId;
    }

    public void setArticleId(String articleId) {
        this.articleId = articleId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getParentFolderId() {
        return ParentFolderId;
    }

    public void setParentFolderId(String parentFolderId) {
        this.ParentFolderId = parentFolderId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<String> getTags() {
        return tags;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }

    public boolean isFavorite() {
        return favorite;
    }

    public void setFavorite(boolean favorite) {
        this.favorite = favorite;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    public Date getLastModifiedTime() {
        return lastModifiedTime;
    }

    public void setLastModifiedTime(Date lastModifiedTime) {
        this.lastModifiedTime = lastModifiedTime;
    }

    public int getViewCount() {
        return viewCount;
    }

    public void setViewCount(int viewCount) {
        this.viewCount = viewCount;
    }

    public int getHelpfulCount() {
        return helpfulCount;
    }

    public void setHelpfulCount(int helpfulCount) {
        this.helpfulCount = helpfulCount;
    }

    public int getNotHelpfulCount() {
        return notHelpfulCount;
    }

    public void setNotHelpfulCount(int notHelpfulCount) {
        this.notHelpfulCount = notHelpfulCount;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getLocale() {
        return locale;
    }

    public void setLocale(String locale) {
        this.locale = locale;
    }

    public String getBaseLngArticleId() {
        return baseLngArticleId;
    }

    public void setBaseLngArticleId(String baseLngArticleId) {
        this.baseLngArticleId = baseLngArticleId;
    }

    public Map<String, String> getLngVariants() {
        return lngVariants;
    }

    public void setLngVariants(Map<String, String> lngVariants) {
        this.lngVariants = lngVariants;
    }

    public MigrationDetails getMigrationDetails() {
        return migrationDetails;
    }

    public void setMigrationDetails(MigrationDetails migrationDetails) {
        this.migrationDetails = migrationDetails;
    }
    
}
