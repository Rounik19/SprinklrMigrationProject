package in.rounik.project.MigratedData;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import in.rounik.project.DumpData.DumpedArticle;
import in.rounik.project.DumpData.DumpedFolder;
import in.rounik.project.Filter.Filter;
import in.rounik.project.Filter.FilterType;
import in.rounik.project.KBObjects.KBArticle;
import in.rounik.project.KBObjects.KBFolder;

@Service
public class MigratedDataServiceImpl implements MigratedDataService {

    @Autowired
    private MigratedFolderRepository folderRepository;

    @Autowired
    private MigratedArticleRepository articleRepository;

    @Autowired
    private MongoTemplate mongoTemplate;

    private final Map<FilterType, BiFunction<String, List<Object>, Criteria>> criteriaMap = new HashMap<>();

    public MigratedDataServiceImpl() {
        criteriaMap.put(FilterType.EQUAL, (field, values) -> Criteria.where(field).is(values.get(0)));
        criteriaMap.put(FilterType.NOT_EQUAL, (field, values) -> Criteria.where(field).ne(values.get(0)));
        criteriaMap.put(FilterType.GT, (field, values) -> Criteria.where(field).gt(values.get(0)));
        criteriaMap.put(FilterType.GTE, (field, values) -> Criteria.where(field).gte(values.get(0)));
        criteriaMap.put(FilterType.LT, (field, values) -> Criteria.where(field).lt(values.get(0)));
        criteriaMap.put(FilterType.LTE, (field, values) -> Criteria.where(field).lte(values.get(0)));
        criteriaMap.put(FilterType.CONTAINING, (field, values) -> Criteria.where(field).regex((String) values.get(0)));
        criteriaMap.put(FilterType.NOT_CONTAINING, (field, values) -> Criteria.where(field).not().regex((String) values.get(0)));
        criteriaMap.put(FilterType.BETWEEN, (field, values) -> Criteria.where(field).gte(values.get(0)).lte(values.get(1)));
        criteriaMap.put(FilterType.IN, (field, values) -> Criteria.where(field).in(values));
        criteriaMap.put(FilterType.NOT_IN, (field, values) -> Criteria.where(field).nin(values));
    }

    @Override
    public Page<KBFolder> getPagedFolders(Pageable pageable) {
        return folderRepository.findAll(pageable);
    }

    @Override
    public long getFoldersCount() {
        return folderRepository.count();
    }

    @Override
    public KBFolder getFolderById(String id) {
        return folderRepository.findById(id).orElse(null);
    }

    @Override
    public boolean deleteFolder(String id) {
        if (folderRepository.existsById(id)) {
            KBArticle article = articleRepository.findById(id).orElse(null);
            article.setDeleted(true);
            return true;
        }
        return false;
    }

    @Override
    public void deleteAllFolders() {
        folderRepository.deleteAll();
    }

    @Override
    public void migrateFolder(DumpedFolder dumpedFolder) {
        boolean isMigrated = dumpedFolder.isMigrated();
        if(!isMigrated) {
            KBFolder kbFolder = dumpedFolder.getFolder();
            folderRepository.save(kbFolder);
            dumpedFolder.setMigrated(true);
        }
    }

    @Override
    public void saveFolder(KBFolder kbFolder) {
        String folderID = kbFolder.getFolderId();
        if(getFolderById(folderID) == null) {
            folderRepository.save(kbFolder);
        }
    }

    @Override
    public Page<KBArticle> getPagedArticles(Pageable pageable) {
        return articleRepository.findAll(pageable);
    }

    @Override
    public long getArticlesCount() {
        return articleRepository.count();
    }

    @Override
    public KBArticle getArticleById(String id) {
        return articleRepository.findById(id).orElse(null);
    }

    @Override
    public boolean deleteArticle(String id) {
        if (articleRepository.existsById(id)) {
            articleRepository.deleteById(id);
            return true;
        }
        return false;
    }

    @Override
    public void deleteAllArticles() {
        articleRepository.deleteAll();
    }

    @Override
    public void migrateArticle(DumpedArticle dumpedArticle) {
        boolean isMigrated = dumpedArticle.isMigrated();
        if(!isMigrated) {
            KBArticle kbArticle = dumpedArticle.getArticle();
            articleRepository.save(kbArticle);
            dumpedArticle.setMigrated(true);
        }
    }

    @Override
    public void saveArticle(KBArticle kbArticle) {
        String articleID = kbArticle.getArticleId();
        if(getArticleById(articleID) == null) {
            articleRepository.save(kbArticle);
        }
    }

    @Override
    public Page<KBFolder> getFilteredPagedFolders(List<Filter> filters, Pageable pageable) {
        Query query = new Query();

        for (Filter filter : filters) {
            BiFunction<String, List<Object>, Criteria> criteriaFunction = criteriaMap.get(filter.getFilterType());
            if (criteriaFunction != null) {
                query.addCriteria(criteriaFunction.apply(filter.getField(), filter.getValues()));
            }
        }

        long total = mongoTemplate.count(query, DumpedFolder.class);
        query.with(pageable);

        List<KBFolder> folders = mongoTemplate.find(query, KBFolder.class);
        return new PageImpl<>(folders, pageable, total);
    }

    @Override
    public Page<KBArticle> getFilteredPagedArticles(List<Filter> filters, Pageable pageable) {
        Query query = new Query();

        for (Filter filter : filters) {
            BiFunction<String, List<Object>, Criteria> criteriaFunction = criteriaMap.get(filter.getFilterType());
            if (criteriaFunction != null) {
                query.addCriteria(criteriaFunction.apply(filter.getField(), filter.getValues()));
            }
        }

        long total = mongoTemplate.count(query, KBArticle.class);
        query.with(pageable);

        List<KBArticle> articles = mongoTemplate.find(query, KBArticle.class);
        return new PageImpl<>(articles, pageable, total);
    }
}
