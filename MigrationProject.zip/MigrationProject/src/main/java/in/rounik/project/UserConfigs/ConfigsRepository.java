package in.rounik.project.UserConfigs;
import org.springframework.stereotype.Repository;

@Repository
public interface ConfigsRepository extends org.springframework.data.mongodb.repository.MongoRepository<Config, String> {
    
}