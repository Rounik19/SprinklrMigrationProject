package in.rounik.project.KBObjects;

import java.util.List;

public class KBFolder {
    private String folderId;
    private String folderName;
    private String parentFolderId;
    private List<String> tags;
    private boolean favorite;
    

    private MigrationDetails migrationDetails;

    public KBFolder() {
    }

    public KBFolder(String folderId, String folderName, String parentFolderId, List<String> tags, boolean favorite, MigrationDetails migrationDetails) {
        this.folderId = folderId;
        this.folderName = folderName;
        this.parentFolderId = parentFolderId;
        this.tags = tags;
        this.favorite = favorite;
        this.migrationDetails = migrationDetails;
    }

    public String getFolderId() {
        return folderId;
    }

    public void setFolderId(String folderId) {
        this.folderId = folderId;
    }

    public String getFolderName() {
        return folderName;
    }

    public void setFolderName(String folderName) {
        this.folderName = folderName;
    }

    public String getParentFolderId() {
        return parentFolderId;
    }

    public void setParentFolderId(String parentFolderId) {
        this.parentFolderId = parentFolderId;
    }

    public List<String> getTags() {
        return tags;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }

    public boolean isFavorite() {
        return favorite;
    }

    public void setFavorite(boolean favorite) {
        this.favorite = favorite;
    }

    public MigrationDetails getMigrationDetails() {
        return migrationDetails;
    }

    public void setMigrationDetails(MigrationDetails migrationDetails) {
        this.migrationDetails = migrationDetails;
    }

}
