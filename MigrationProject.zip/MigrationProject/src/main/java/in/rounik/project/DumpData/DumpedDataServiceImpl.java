package in.rounik.project.DumpData;

import in.rounik.project.Filter.Filter;
import in.rounik.project.Filter.FilterType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;

@Service
public class DumpedDataServiceImpl implements DumpedDataService {

    @Autowired
    private DumpedFolderRepository dumpedFolderRepository;

    @Autowired
    private DumpedArticleRepository dumpedArticleRepository;

    @Autowired
    private MongoTemplate mongoTemplate;

    private final Map<FilterType, BiFunction<String, List<Object>, Criteria>> criteriaMap = new HashMap<>();

    public DumpedDataServiceImpl() {
        criteriaMap.put(FilterType.EQUAL, (field, values) -> Criteria.where(field).is(values.get(0)));
        criteriaMap.put(FilterType.NOT_EQUAL, (field, values) -> Criteria.where(field).ne(values.get(0)));
        criteriaMap.put(FilterType.GT, (field, values) -> Criteria.where(field).gt(values.get(0)));
        criteriaMap.put(FilterType.GTE, (field, values) -> Criteria.where(field).gte(values.get(0)));
        criteriaMap.put(FilterType.LT, (field, values) -> Criteria.where(field).lt(values.get(0)));
        criteriaMap.put(FilterType.LTE, (field, values) -> Criteria.where(field).lte(values.get(0)));
        criteriaMap.put(FilterType.CONTAINING, (field, values) -> Criteria.where(field).regex((String) values.get(0)));
        criteriaMap.put(FilterType.NOT_CONTAINING, (field, values) -> Criteria.where(field).not().regex((String) values.get(0)));
        criteriaMap.put(FilterType.BETWEEN, (field, values) -> Criteria.where(field).gte(values.get(0)).lte(values.get(1)));
        criteriaMap.put(FilterType.IN, (field, values) -> Criteria.where(field).in(values));
        criteriaMap.put(FilterType.NOT_IN, (field, values) -> Criteria.where(field).nin(values));
    }

    @Override
    public long getFoldersCount() {
        return dumpedFolderRepository.count();
    }

    @Override
    public DumpedFolder getFolderById(String id) {
        return dumpedFolderRepository.findById(id).orElse(null);
    }

    @Override
    public boolean deleteFolder(String id) {
        DumpedFolder folder = dumpedFolderRepository.findById(id).orElse(null);
        if (folder == null) {
            return false;
        }
        dumpedFolderRepository.delete(folder);
        return true;
    }

    @Override
    public void deleteAllFolders() {
        dumpedFolderRepository.deleteAll();
    }

    @Override
    public void saveFolder(DumpedFolder dumpedFolder) {
        String folderID = dumpedFolder.getFolder().getFolderId();
        if (!checkFolderByFolderID(folderID)) {
            dumpedFolderRepository.save(dumpedFolder);
        } 
    }

    private boolean checkFolderByFolderID(String folderID) {
        Filter filter = new Filter("folder.folderId", FilterType.EQUAL, List.of(folderID));
        List<Filter> filters = List.of(filter);
        Page<DumpedFolder> dumpedFolders = getFilteredPagedFolders(filters, Pageable.unpaged());
        return dumpedFolders.getTotalElements() > 0;
    }

    @Override
    public long getArticlesCount() {
        return dumpedArticleRepository.count();
    }

    @Override
    public DumpedArticle getArticleById(String id) {
        return dumpedArticleRepository.findById(id).orElse(null);
    }

    @Override
    public boolean deleteArticle(String id) {
        DumpedArticle article = dumpedArticleRepository.findById(id).orElse(null);
        if (article == null) {
            return false;
        }
        dumpedArticleRepository.delete(article);
        return true;
    }

    @Override
    public void deleteAllArticles() {
        dumpedArticleRepository.deleteAll();
    }

    @Override
    public void saveArticle(DumpedArticle dumpedArticle) {
        String articleID = dumpedArticle.getArticle().getArticleId();
        if (!checkArticleByArticleID(articleID)) {
            dumpedArticleRepository.save(dumpedArticle);
        }
    }

    private boolean checkArticleByArticleID(String articleID) {
        Filter filter = new Filter("article.articleId", FilterType.EQUAL, List.of(articleID));
        List<Filter> filters = List.of(filter);
        Page<DumpedArticle> dumpedArticles = getFilteredPagedArticles(filters, Pageable.unpaged());
        return dumpedArticles.getTotalElements() > 0;
    }

    @Override
    public Page<DumpedFolder> getFilteredPagedFolders(List<Filter> filters, Pageable pageable) {
        Query query = new Query();

        for (Filter filter : filters) {
            BiFunction<String, List<Object>, Criteria> criteriaFunction = criteriaMap.get(filter.getFilterType());
            if (criteriaFunction != null) {
                query.addCriteria(criteriaFunction.apply(filter.getField(), filter.getValues()));
            }
        }

        long total = mongoTemplate.count(query, DumpedFolder.class);
        query.with(pageable);

        List<DumpedFolder> folders = mongoTemplate.find(query, DumpedFolder.class);
        return new PageImpl<>(folders, pageable, total);
    }

    @Override
    public Page<DumpedArticle> getFilteredPagedArticles(List<Filter> filters, Pageable pageable) {
        Query query = new Query();

        for (Filter filter : filters) {
            BiFunction<String, List<Object>, Criteria> criteriaFunction = criteriaMap.get(filter.getFilterType());
            if (criteriaFunction != null) {
                query.addCriteria(criteriaFunction.apply(filter.getField(), filter.getValues()));
            }
        }

        long total = mongoTemplate.count(query, DumpedArticle.class);
        query.with(pageable);

        List<DumpedArticle> articles = mongoTemplate.find(query, DumpedArticle.class);
        return new PageImpl<>(articles, pageable, total);
    }

}
